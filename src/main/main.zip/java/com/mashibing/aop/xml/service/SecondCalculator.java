package com.mashibing.aop.xml.service;

public class SecondCalculator implements Calculator {
    public Integer add(Integer i, Integer j) throws NoSuchMethodException {
        return null;
    }

    public Integer sub(Integer i, Integer j) throws NoSuchMethodException {
        return null;
    }

    public Integer mul(Integer i, Integer j) throws NoSuchMethodException {
        return null;
    }

    public Integer div(Integer i, Integer j) throws NoSuchMethodException {
        return null;
    }
}
