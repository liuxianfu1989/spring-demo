package com.mashibing.supplier;

public class CreateSupplier {

    public static User createUser(){
        return new User("zhangsan");
    }
}
