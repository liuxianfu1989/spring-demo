package com.mashibing;

import com.mashibing.selfbdrpp.Teacher;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Component;

//@Component
public class PersonService {
}
