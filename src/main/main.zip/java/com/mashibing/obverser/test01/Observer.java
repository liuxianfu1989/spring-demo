package com.mashibing.obverser.test01;

/**
 * 观察者
 */
public interface Observer {

    public void make(String str);
}
