package com.mashibing.cycle;

public class B {

//   private C c;
//
//    public C getC() {
//        return c;
//    }
//
//    public void setC(C c) {
//        this.c = c;
//    }

    private A a;

    public A getA() {
        return a;
    }


    public void setA(A a) {
        this.a = a;
    }

//    @Override
//    public String toString() {
//        return "B{" +
//                "a=" + a +
//                '}';
//    }
}
