package com.mashibing.cycle;

public class Logger {
    
    public void recordBefore(){
        System.out.println("recordBefore");
    }
    
    public void recordAfter(){
        System.out.println("recordAfter");
    }
    
}