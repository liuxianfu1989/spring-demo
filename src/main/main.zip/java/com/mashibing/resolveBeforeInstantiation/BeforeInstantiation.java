package com.mashibing.resolveBeforeInstantiation;

public class BeforeInstantiation {

    public void doSomeThing(){
        System.out.println("执行do some thing....");
    }
}
