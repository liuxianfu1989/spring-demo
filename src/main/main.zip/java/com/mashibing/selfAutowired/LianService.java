package com.mashibing.selfAutowired;

import org.springframework.stereotype.Service;

@Service
public class LianService {

    public void show(){
        System.out.println("哈哈哈-----");
    }
}
