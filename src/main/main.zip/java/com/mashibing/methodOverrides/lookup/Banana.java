package com.mashibing.methodOverrides.lookup;

public class Banana extends Fruit {
    public Banana() {
        System.out.println("I got a  fresh bananer");
    }
}