package com.mashibing.methodOverrides.lookup;

public class Fruit {
    public Fruit() {
        System.out.println("I got Fruit");
    }
}