package com.mashibing.merged;

import org.springframework.stereotype.Component;

//@Component
public class PersonDao {
}
